# Changes

## 0.8.2 (2026111802)
- AI quiz maker: tidier "Make it from" choices and price label.
- Quiz titles made from file names read naturally ("Leading teams" instead of "leading-teams").

## 0.8.1 (2026111801)
- Fixed: presenting PowerPoint, Word and Excel files failed after the rename.
- Tested on Moodle 4.5, 5.2 and 5.3.

## 0.8.0 (2026111800)
- Renamed to AI Virtual Classroom (mod_aivirtualclassroom). Install it as a new plugin; it does not upgrade LMS LiveLab activities.
- PowerPoint upload: teachers can upload .pptx, .ppt, .pps or .odp straight into the class. With LibreOffice on the Moodle server the slides keep their transitions and animations, and everyone sees each animation step in sync; otherwise slides are converted through LMS Labs.

## 0.7.2 (2026111700)
- Studio quality no longer freezes the page: the cut-out model now runs in a background worker, so video, buttons and audio stay responsive on any computer. Slow computers drop back to standard quality on their own.
- Lighter edge refinement (same quality, about a third of the graphics work).
- If the graphics chip resets, effects switch off with a message instead of leaving a frozen picture.

## 0.7.1 (2026111601)
- Join screen: choose Background (None, Blur, pictures, your own), Studio quality and Smooth skin before joining, with a live preview. The same choices are in More during the class.
- Studio quality: fixed a crash when switching it on while an effect was running. Effect changes now apply one at a time, the model finishes loading before the old video stops, and the model runs up to 16 times a second to keep the computer cool.

## 0.7.0 (2026111600)
- Studio quality background: a hair-level matting model (Robust Video Matting) that follows flyaway hair and edges and stays steady between frames. Switch it on in More > Background. Runs on the computer's graphics chip (WebGPU); the model ships inside the plugin and is kept by the browser after first use. Computers that cannot keep up drop back to standard quality automatically.

## 0.6.7 (2026111500)
- Background cut-out: edges now follow the real colours of the picture (guided filter), and smoothing adapts to movement: steady when still, no ghosting when you move.

## 0.6.6 (2026111401)
- Stronger background blur (about twice as strong), with no dark edges around the frame.

## 0.6.5 (2026111400)
- Much cleaner background cut-out: a better person model (separates hair, face, body and clothes), edges refined on the GPU with the full-resolution picture, smoothed between frames to stop flicker, and blended softly into the new background. Runs at full camera resolution and frame rate.

## 0.6.4 (2026111300)
- Virtual backgrounds (no green screen needed): More > Background. Choose None, Blur, six built-in backgrounds (Studio, Lavender, Ocean, Sunset, Bright office, Forest) or upload your own picture, kept on that device only.
- Change my name: More > Change my name, the pencil on the join screen, or Edit name in People. Empty resets to the Moodle name. Teachers still see the Moodle name next to a changed name; attendance and grades always use the real Moodle user.

## 0.6.3 (2026111200)
- Smooth skin: one click in More. A GPU touch-up softens skin only, keeps eyes, hair and the background sharp, and runs at full HD. Works together with background blur and is remembered for next time.
- Background blur keeps the camera's full resolution.
- Flying reactions float up more slowly (7 seconds instead of 4).

## 0.6.2 (2026111101)
- When Central Config already has the Site ID and API key, the activity page no longer asks for them; it says AI Virtual Classroom is connecting to LMS Labs.

## 0.6.1 (2026111100)
- Settings page shows the green "Central Config active" check like every LMS Labs plugin, with the AI Virtual Classroom connection status on its own line.
- No Site ID or API key fields when Central Config is installed.

## 0.6.0 (2026111001)
- Zero setup: AI Virtual Classroom uses the Site ID and API key from LMS Labs Central Config, like every LMS Labs plugin. It fetches its own security key from lms-labs.com on first use.
- Removed the Worker URL, Site ID, Shared secret, Max cameras and Simulcast settings. The live class service is built in and simulcast is always on.
- The settings page shows whether the site is connected.
- The attendance report shows learner-hours and the matching credits instead of data use.
- Copy button for the guest invite link.

## 0.5.0 (2026110900)
- Renamed to AI Virtual Classroom.
- Full HD 1080p trainer camera, HD 720p learner cameras, Full HD screen share (2 Mbps), 30 fps.
- AI class summary at the end of each class (captions, shared notes and slides), shown on the activity page.
- "AI summary" button in private notes: summarises the learner's own notes with the class context.
- Works with the AI Virtual Classroom SFU servers (self-hosted, load-balanced, cascading for big classes) as well as Cloudflare Realtime.
- Billing by learner-hours from LMS Labs credits (1 credit = 3 learner-hours); trainers are never counted.

## 0.3.0 (2026-11-07)
- Student boards: split-screen view of every student's board, mark all or one correct, pen, ticks, crosses and stamps; students can hide their name or picture.
- Captions and translation: one-question language picker, Whisper correction with key terms and slide text, sentence translation with context, "hear the class in my language".
- New design for the meeting room and join screen.
- Media reconnects by itself after a network drop instead of asking for a reload.
- Recording: profile pictures and names drawn on tiles; an empty stage records everyone instead of a blank frame; nothing-recorded case handled.
- Attendance report: download button at the top, teachers shown as "Teacher".
- New settings: Simulcast (site), Key terms for captions (activity).
- Students with no breakout room set in Moodle (and guests) now join the emptiest room instead of staying alone in the main room.
- Marketplace readiness: thirdpartylibs.xml, supported versions, notes stored as plain text, comments on the two intentionally public endpoints (signed webhook, guest link).
- "All boards" stays in the marking toolbar after changing tool.

## 0.2.0
- First complete release: breakouts per teacher, attendance and hand-raise completion, recordings emailed to students, whiteboard, slides, polls, Q&A, notes, bandwidth savers.
